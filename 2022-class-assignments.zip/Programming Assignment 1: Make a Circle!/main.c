int main()
{
    printf("Welcome to my program!\n");
    
    double circleRadius;
    
    printf("Enter Circle Radius: \n");
    scanf("%lf", & circleRadius);
    
    printf("Circle Radius: %f\n", circleRadius);
    printf("Circle Diameter: %f\n", 2 * circleRadius);
    printf("Circle Circumference: %f\n", 3.1415 * 2 * circleRadius);
    printf("Circle Area: %f\n", 3.1415 * pow(circleRadius, 2));

    return 0;
}

