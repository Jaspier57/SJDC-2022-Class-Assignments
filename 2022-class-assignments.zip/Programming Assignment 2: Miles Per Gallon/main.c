/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Welcome to my program!\n");
    
    double usedGallons;
    double drivenMiles;
    
    printf("Enter the gallons used (-1 to end): \n");
    scanf("%lf", & usedGallons);

    printf("Enter the miles driven: \n");
    scanf("%lf", & drivenMiles);

    printf("The miles / gallon for this tank was %f\n", drivenMiles/usedGallons);

    return 0;
}

